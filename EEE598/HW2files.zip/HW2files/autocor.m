clear all
close all
clc
% fp = fopen('TIMIT_ver110train_0001.raw','rb');
% s = fread(fp,'short');
% seg=s(15100:15419);
seg=[1 2 0 0 0 2 0 1 0 2 1 0 0 0]';
P=4;             % order for estimation
R=zeros(1,P);      % AutoCorrelation vector
% Compute Autocorrelation
for taw=0:P
    index=taw+1;
    R(index)=sum(seg(1+index-1:end).*seg(1:end-index+1));
end
rn=R(2:end)';
R=R(1:end-1);
% Generate Autocorrelation matrix
Rm=zeros(P);
Rm(1,:)=R;
for ii=2:P
    Rm(ii,:)=[R(ii:-1:2),R(1:end-ii+1) ];
end
Alpha=inv(Rm)*rn
%%% using alphas for estimating the signal
seg_estimated=zeros(size(seg));
seg_estimated(1:P)=seg(1:P);
for si=P+1:length(seg)
    seg_estimated(si)=sum(seg(si-P:si-1).*Alpha(end:-1:1));
end
subplot(3,1,1)
plot(seg_estimated(P+1:end))
title('estimated segment')
subplot(3,1,2)
plot(seg(P+1:end))
title('seg')
subplot(3,1,3)
Error=(seg(P+1:end)-seg_estimated(P+1:end)).^2;
plot(Error)
title('Error')