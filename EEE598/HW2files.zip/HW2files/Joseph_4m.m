close all;
clear all;
clc


% When using Online MATLAB
% addpath("MATLAB_Drive")

audio_file = "Shortpuhtuh.wav"; 

% read in audio file 
[y,fs] = audioread(audio_file);

% variables that can be changed 
window_seconds = 0.5; 
overlap_seconds = 0.25; 
window = window_seconds*fs; 
overlap = overlap_seconds*fs; 

aco= []; 
for i = [1:(window-overlap-1):length(y)] 
    sig1 = y(1:end-((i-1)*1)); 
    sig2 = y(((i-1)*1)+1:end); 
    
    % plot the data and save the autocorrelation for that index 
    subplot(211) 
    plot(y) 
    hold on 
    
    % put zero in front to show where window is on graph 
    zzz = zeros(i,1); 
    plot([zzz; sig1],'r') 
    hold off 
    aco = [aco; sum(sig1.*sig2)]; 
    
    subplot(212) 
    plot(aco) 
    pause(0.05) 
end 

figure 
hold on 
plot(aco) 

plot(envelope(aco,10,'peak')) 
[pks,locs] = findpeaks(envelope(aco,1,'peak'));
[pks,locs] = findpeaks(aco); 
scatter(locs,pks,'b') 

temp_bin = [];
for i = 1:length(locs)-1 
    temp_bin(i) = locs(i+1)-locs(i); 
end 

% diff = []; 
% for i = [1:(window-overlap-1):length(y)] 
% sig1 = y(1:end-((i-1)*1)); 
% sig2 = y(((i-1)*1)+1:end); 

% plot the data and save the autocorrelation for that index 
% subplot(211) 
% plot(y) 
% hold on 
 
% put zero in front to show where window is on graph 
% zzz = zeros(i,1); 
% plot([zzz; sig1],'r') 
% hold off 
% diff = [diff; sum(sig1-sig2)]; 
% subplot(212) 
% hold on 
% plot(diff) 
% yline(0) 
% hold off 
% 
% pause(0.05) 

% https://www.mathworks.com/help/signal/ug/power-spectral-density-estimates-using-fft.html
