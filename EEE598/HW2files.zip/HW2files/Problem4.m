clear
clc

% taw = lag
% j = index for loop
% W = integration window
% sum(X_j.*X_jtao)

% [x, fs] = audioread("shortpuhtuh.wav");
% 
% W = 550;
% 
% sig1 = x; % X_j
% sig2 = [zeros(taw,1); x]; % X_jtao

% sound(sig1, fs)
% sound(sig2, fs)
% plot(sig1);
% hold on
% plot(sig2);
% hold off


% for taw = 1:100
%     sig1 = x; % X_j
%     sig2 = [zeros(taw,1); x]; % X_jtao
% 
%     beginning_line = 1+((taw-1)*1);
%     ACF = sum(sig1(beginning_line:beginnings_line + W).*sig2(beginning_line + W));
% end

% Time shift
% We introduce one second of silence in the signal x
% y = conv(b,x);
% x_shifted = [zeros(fs,1); x];
% y_shifted = conv(b,x_shifted);
% 
% subplot(311)
% plot([zeros(fs,1); y])
% title("Avg filtered and then shifted")
% subplot(312)
% plot(y_shifted)
% title("Shifted and then avg filtered")
% subplot(313)
% plot(y_shifted - [zeros(fs,1); y]);
% title("The difference")


%% % https://youtu.be/W585xR3bjLM
% python

% from scipy import signal
% import numpy as np

% def f(x):
%   f_0 = 1
%   return np.sin(x * np.pi * 2 * f_0)

% def ACF(f, W, t, lag):
%   return np.sum(f[t : t+W] * f[lag+t: lag+t+W])

% def detect_pitch(f, W, t, sample_rate, bounds):
%   ACF_vals = [ACF(f, W, t, i) for i in range(*bounds)]
%   sample = np.argmax(ACF_vals) + bounds[0]
%   return sample_rate / sample

% def main():
%   sample_rate = 500
%   start = 0
%   end = 5
%   num_samples = int(sample_rate * (end - start) + 1))
%   window_size = 200
%   bounds = [20, num_samples // 2]

%   x = np.linspace(start, end, num_samples)
%   print(detect_pitch(f(x), window_size, 1, sample_rate, bounds))

[x, fs] = audioread("shortpuhtuh.wav");
window_size = 20/1000 * fs;
bounds = [40:800];

pitches = [];

x_size = length(x);
for i = 1:floor(x_size/(window_size+2))
    pitches(i) = detect_pitch(x, window_size, 1, fs, bounds);
end

plot(pitches)

sample = f(x);
detect_pitch(sample, window_size, 1, fs, bounds)

% 1 Hz sample
function sample = f(x)
    f_0 = 1;
    sample = sin(x * pi * 2 * f_0);
end

% Autocorrelation function
function similarity = ACF(sig, W, t, lag) % window_size, timestep
    similarity = sum(sig(t:t+W).*sig(t+lag:t+lag+W));
end

% ACF detect pitch
function pitch = detect_pitch(sig, W, t, fs, bounds)
    ACF_vals = zeros(length(bounds));
    cnt = 1;
    for i = min(bounds):max(bounds)
        ACF_vals(cnt) = ACF(sig, W, t, i);
        cnt = cnt+1;
    end
    [~, argmax] = max(ACF_vals);
    sample = argmax + bounds(1);
    pitch = fs / sample;
end

