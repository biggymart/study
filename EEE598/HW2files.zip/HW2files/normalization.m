clear
clc

a = [1, 3, 4, 5, 6];
b = [1,51, 25, 6, 22];

mean(a)
mean(b)

a= normalize(a, 'center');
b= normalize(b, 'center');

mean(a)
mean(b)