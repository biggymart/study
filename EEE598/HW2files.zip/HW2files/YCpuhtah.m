clear
clc

%% 0. load file and processing
[x, old_fs] = audioread("puhtuh.wav"); % read original file "puhtuh.wav" 82 repetitions
new_fs = 16000; 
x = resample(x, new_fs, old_fs); % resample the 44.1 kHz to 16 kHz
fprintf("Length of original file: %.2f seconds", length(x)/new_fs)

len = 25; % length of audiofile in sec
t = 1:size(x,1);

%% 1. using autocorrelation, estimate DDK rate
% (sliding window = 4 sec)

aco = []; % empty vector

how_many_puhtuh = []; % how many "puh-tah" in a window

% loop over the whole length of the audiofile
window_sec = 4;
window_len = window_sec * new_fs;
overlap = 3 * new_fs;
jump = window_len/(window_sec * 100);
offset = 50;
syl = 2;

%%
abc = 0;
for i = 1:(window_len-overlap):length(x)
    if ((i+window_len-1) > length(x))
        break
    else
    abc = abc + 1;
    end
end

locs_bin = zeros(abc,1);
%%
mean_tmp = [];

out_cnt = 0;
for i = 1:(window_len-overlap):length(x)

    if ((i+window_len-1) > length(x))
        disp('out of range')
        break
    else
        out_cnt = out_cnt + 1;
        disp(strcat("Working on ", num2str(out_cnt)," window"))

        % Calculate energy contour
        E = abs(x(i:i+window_len-1)).^2;
%         plot([1:window_len], E)
        
        aco = zeros(window_len,1);
        for j = 1:jump:window_len
%             disp(strcat("J =", num2str(j)))

            sig1 = E(1:end-((j-1)*1));
            sig2 = E(((j-1)*1)+1:end);
            aco(j) = sum(sig1.*sig2);

%             subplot(211)
%             plot(sig1, 'r')
%             hold on
%             plot(sig2,'g')
%             hold off
%             subplot(212)
%             plot(aco)
            
%             pause(0.1)
        end
        
        subplot(311)
        plot(aco)
        keyboard

        [up, ~] = envelope(aco(50:end), 10, 'peak');
        
        subplot(312)
        plot(up)
        keyboard
        
%         Moving average smoothing
        B = 1/(jump*5)*ones(jump*5,1);
        filtered_up = filter(B,1,up);
        subplot(313)
        plot(filtered_up)
        hold on

%         Find local maximum
        [pks, locs] = findpeaks(filtered_up, 'MinPeakDistance', 1e3, 'MinPeakHeight', 0.001 * window_sec);

        plot(locs, pks, 'o')
        hold off
        keyboard

        puh_tah = length(pks)/syl;
        how_many_puhtuh(out_cnt) = puh_tah;

    end
end
disp(mean(how_many_puhtuh) / window_sec)
% disp(mean(how_many_puhtuh) * ((length(x)/new_fs)/window_sec)))
plot(1:length(how_many_puhtuh), how_many_puhtuh)

