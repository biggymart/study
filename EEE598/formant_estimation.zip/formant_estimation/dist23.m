function d23=dist23(F1,F2)
%
% function to compute distance between two formant vectors, each with two
% formants
%
% Inputs:
%   F1: 2 element vector with f2 and f3 for one frame
%   F2: 2 element vector with f2 and f3 for second frame
%
% Output:
%   d23: normalized distance between F1 and F2

    d23=((F1(1)-F2(1))/F1(1))^2+((F1(2)-F2(2))/F1(2))^2;
end