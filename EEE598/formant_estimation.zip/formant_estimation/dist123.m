function d123=dist123(F1,F2)
%
% function to compute distance between two formant vectors, each with three
% formants
%
% Inputs:
%   F1: 3 element vector with f1 and f2 and f3 for one frame
%   F2: 3 element vector with f1 and f2 and f3 for second frame
%
% Output:
%   d123: normalized distance between F1 and F2

    % fprintf('F1: %6.2f %6.2f %6.2f \n',F1(1:3));
    % fprintf('F2: %6.2f %6.2f %6.2f \n',F2(1:3));
    d123=((F1(1)-F2(1))/F1(1))^2+((F1(2)-F2(2))/F1(2))^2+((F1(3)-F2(3))/F1(3))^2;
    % fprintf('d123:%8.2f \n',d123);
    % pause
end