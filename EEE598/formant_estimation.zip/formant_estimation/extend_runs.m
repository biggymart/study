function [Fmc,startsav,endsav]=extend_runs(nrun,startsav,endsav,nfrm,f1,Fm,nfmt,FS,dthr,fidw)
%
% function to extend regions of formant runs based on adjacent frames
%
% basic rule is that we search backwards from the beginning frame of each 
% formant region and we search forwards from the ending frame of each
% region
%   The rule for extending the regions is that the extended frame has at
%   least two identified formants whose distance to the existing formants
%   is sufficiently small to justify extending the region; all extensions
%   that are not part of regions are set to NaN for plotting purposes
%
% Inputs:
%   nrun: number of runs of formants with a consistent number of formants
%   startsav(1:nrun): starting frame number of each run
%   endsav(1:nrun): ending frame number of each run
%   nfrm: number of frames in speech file
%   f1(1:nfrm): count of number of formants in each frame
%   Fm(1:nfmt,1:nfrm): saved formant tracks 
%   nfmt: maximum number of formants in a frame (4)
%   FS(1:4,1:nfrm): sorted formants, sorted by frequency
%   dthr: distance threshold on closeness of formants
%   fidw: file id for writing output
%
% Output:
%   Fmc(1:nfmt,1:nfrm): saved formant tracks
%   startsav(1:nrun): starting frame number of each run
%   endsav(1:nrun): ending frame number of each run
    
% First we clearly define the beginning and end of each of the formant
% regions
    beginf=startsav;
    endf=endsav;
    
% For each region begin at beginning frame and go backwards one frame at a
% time until the relative match exceeds a threshold
    for run=1:nrun
        bf=beginf(run);
        if (run == 1)
            ef=1;
        else
            ef=endf(run-1);
        end
        
% now search backwards for matches; we assume that there are at least 3
% formants for the formant regions and at least 2 formants for the
% potential matching frames
        for index=bf-1:-1:ef+1
            d12=dist12(Fm(1:2,index),Fm(1:2,index+1));
            d23=dist23(Fm(2:3,index),Fm(2:3,index+1));
            Fm(4,index)=NaN;
            if (d12 < dthr)
                beginf(run)=index;
                Fm(3,index)=NaN;
            elseif (d23 < dthr)
                beginf(run)=index;
                Fm(1,index)=NaN;
            else
                Fm(1:3,index)=NaN;
                break;
            end
        end
    end
    
% save all changes in startsav and endsav
    startsav=beginf;
    endsav=endf;
    
    for run=1:nrun
        fb=startsav(run);fe=endsav(run);
        fprintf(fidw,'after begin: run:%d, start:%d, end:%d \n',run,fb,fe);
    end
      
% For each region begin at ending frame and go forwards one frame at a
% time until the relative match exceeds a threshold
    for run=1:nrun
        bf=endf(run);
        if (run == nrun)
            ef=nfrm;
        else
            ef=beginf(run+1)-1;
        end
        
% now search forward for matches; we assume that there are at least 3
% formants for the formant regions and at least 2 formants for the
% potential matching frames
        for index=bf+1:ef
            d12=dist12(Fm(1:2,index),Fm(1:2,index-1));
            d23=dist23(Fm(2:3,index),Fm(2:3,index-1));
            Fm(4,index)=NaN;
            if (d12 < dthr)
                endf(run)=index;
                Fm(3,index)=NaN;
            elseif (d23 < dthr)
                endf(run)=index;
                Fm(1,index)=NaN;
            else
                Fm(1:3,index)=NaN;
                break;
            end
        end
    end
    
% save all changes in startsav and endsav
    startsav=beginf;
    endsav=endf;
    
    for run=1:nrun
        fb=startsav(run);fe=endsav(run);
        fprintf(fidw,'after end: run:%d, start:%d, end:%d \n',run,fb,fe);
    end

% remove all formant estimates between regions
        Fmc=Fm;
        if (beginf(1) > 1)
            Fmc(1:4,1:beginf(1)-1)=NaN;
        end
        if (endf(nrun) < nfrm)
            Fmc(1:4,endf(nrun)+1:nfrm)=NaN;
        end
    for run=2:nrun
        if (beginf(run) > endf(run-1)+1)
            Fmc(1:4,endf(run-1)+1:beginf(run)-1)=NaN;
        end
    end
    
% save all changes in startsav and endsav
    startsav=beginf;
    endsav=endf;
end