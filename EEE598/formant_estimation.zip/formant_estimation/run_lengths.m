function [nrun,startsav,endsav]=run_lengths(f1,nfrm,FS,dthr,fidw)
%
% function to find runs (of at least length 5 frames) of stable formants 
% with at least 3 formants during the entire interval
%
% Inputs:
%   f1: number of formants at each frame
%   nfrm: number of frames in speech file
%   FS: formant estimates from lpc processing, FS(p,nfrm), where p=16 is
%   LPC order
%   dthr: distance threshold on formant distances
%   fidw: output file for writes
%
% Outputs:
%   nrun: number of interval runs with at least 5 frames
%   startsav: initial frame of each valid run
%   endsav: final frame of each valid run

% initialize nrun to -1
    nrun=-1;
    
% determine formant distance between adjacent frames based on simple sum of
% squares of weighted differences between formant values
    for index=1:nfrm-1
        dist(index)=dist123(FS(1:3,index),FS(1:3,index+1));
        if (isnan(dist(index)))
            dist(index)=100;
        end
    end
    fprintf(fidw,'frame distances: \n');
    fprintf(fidw,'dist: %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f \n',dist(1:nfrm-1));
    fprintf(fidw,'  \n');
   
% compress distance array into 0 for below threshold and 1 for above
% threshold
    dist(find(dist <= dthr))=0;
    dist(find(dist > dthr))=1;
    lrun=1;
    state=0;
    for index=1:nfrm-2
        if (dist(index) == 0)
            if (state == 0)
                startsav(lrun)=index;
                state=1;
            end
        elseif (dist(index) == 1)
            if (state == 1)
                endsav(lrun)=index;
                if (endsav(lrun)-startsav(lrun)+1 > 4)
                    lrun=lrun+1;
                end
                state=0;
            end
        end
    end
    if (dist(nfrm-1) == 0)
        if (state == 1)
            endsav(lrun)=nfrm;
            nrun=lrun;
        end
    else
        nrun=lrun-1;
    end
    fprintf('nrun:%d \n',nrun);
end
        