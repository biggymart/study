function d12=dist12(F1,F2)
%
% function to compute distance between two formant vectors, each with two
% formants
%
% Inputs:
%   F1: 2 element vector with f1 and f2 for one frame
%   F2: 2 element vector with f1 and f2 for second frame
%
% Output:
%   d12: normalized distance between F1 and F2

    d12=((F1(1)-F2(1))/F1(1))^2+((F1(2)-F2(2))/F1(2))^2;
end