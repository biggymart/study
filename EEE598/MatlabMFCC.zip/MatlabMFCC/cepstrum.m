clear
clc
close all


[x1 fs1] = audioread('sustained_iy.wav');
x1 = resample(x1,160,441);
fs1 = 16000;
nstart = 2.1e4;
nend = nstart + (floor((20/1000)*fs1)-1);
Nfft = 512;
f = linspace(0,fs1/2,Nfft/2);

x1 = x1(nstart:nend);


X = fft(x1,Nfft);
Xlogabs = log(abs(X));
Xphase = angle(X);


C = ifft(Xlogabs)
% figure
% subplot(211)
% plot(x1)
% subplot(212)
% plot(Xlogabs(1:Nfft/2))
% figure
% plot(abs(C(1:Nfft/2)))
% pause

Nzero = 20;

lifter = 1;

figure(1)
plot(abs(C),'k')
hold on

if lifter == 1
    C(2:Nzero) = 0;
    C(end:-1:end-Nzero-2) = 0
else
    C(Nzero+1:end-Nzero-2) = 0;
end

Xlogabs_r = real(fft(C));


plot(sign(abs(C)))
plot(abs(C),'r','Linewidth',2)
hold off


figure(2)
plot(f,Xlogabs(1:Nfft/2),'k')
hold on
plot(f,Xlogabs_r(1:Nfft/2),'r','LineWidth',2)
hold off


return
