clear
clc
close all


[x1 fs1] = audioread('sustained_iy.wav');
x1 = resample(x1,160,441);
fs1 = 16000;
x1 = x1(1.8e4:end);

%[x1 fs1] = wavread('uai.wav');


fs = fs1;


fr_len = 40;        % 20 ms frame
fr_N = ((20/1000)*fs);
shift_R = fr_N/4;

AAcum = [];

for i = 1:shift_R:5*fs
    tic
    n=[i:i+fr_N-1];
    xframe = x1(n);

    A = lpc(xframe,10);
    RC = lpcar2rf(A);
    AA = lpcrf2aa(RC);

    AAcum = [AAcum; AA];
    
    
    plot(sqrt(AA))
    hold on
    plot(-sqrt(AA))
    hold off
    time_elapsed = toc;
    if time_elapsed < fr_len
        pause((fr_len/1000) - time_elapsed)
    end
    
    figure(1)
    plot(xframe)
    
    figure(2)
    freqz(1,A);
    
    figure(3)
    plot(0.5+sqrt(AA(1:end)),'Linewidth',2)
    hold on
    plot(-0.5-sqrt(AA(1:end)),'Linewidth',2)
    hold off
    
    pause
     
end

plot(mean(AAcum))

