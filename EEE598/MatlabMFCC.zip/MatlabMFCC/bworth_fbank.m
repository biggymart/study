function bworth_fbank(nchan, fs)

fs = 16000;
cf = [240 360 480 600 720 840 1000 1150 1300 1450 1600 1800 2000 2200 2400 2700 3000 3300 3750]';
bw = [120 120 120 120 120 120 150 150 150 150 150 200 200 200 200 300 300 300 500]';

cf_nchan = interp1([1:19],cf,linspace(1,19,nchan))';

for i = 1:(nchan-1)
    bw_nchan(i) = cf_nchan(i+1) - cf_nchan(i); 
end
bw_nchan(end+1) = bw(end)*(19/nchan);
bw_nchan = bw_nchan';


fc1 = [cf_nchan-bw_nchan/2 cf_nchan+bw_nchan/2]/(fs/2);

for i = 1:length(fc1)
    
    [b,a] = butter(2,fc1(i,:),'bandpass')
    freqz(b,a)
    hold on;
    pause(0.1)
end
