clear
clc


[x , ~] = audioread('sustained_iy.wav');
x = resample(x,160,441);
fs = 16000;


xp = x(1.3e4:3.4999e4);

fr_len = 20;        % 20 ms frame
fr_N = ((fr_len/1000)*fs);
shift_R = fr_N;

XP_FRAME_avg = zeros(fr_N,1);
cnt = 0;
for i = 1:shift_R:(length(xp)-fr_N)
    cnt = cnt+1;
    n=i:i+fr_N-1;
    
    w = window(@hamming,fr_N);
    xp_frame = xp(n).*w;
    
     XP_FRAME = abs(fft(xp_frame));
%     plot(20*log10(XP_FRAME))
%     pause
    XP_FRAME_avg = XP_FRAME_avg + XP_FRAME;
       
end
XP_FRAME_avg = XP_FRAME_avg/cnt;
f = linspace(0, fs/2,fr_N/2); 
plot(f,20*log10(XP_FRAME_avg(1:(fr_N/2))))
pause


for i = 1:9
    B = fir1(1024,1-(i/10));
    xp_filt = filter(B,1,xp);
    XP_FILT = fft(xp_filt);
    subplot(211)
    freqz(B,1)
    subplot(212)
    f = linspace(0, fs/2,length(xp_filt)/2); 
    plot(f,20*log10(abs(XP_FILT(1:(length(xp_filt)/2)))))
    
    soundsc(xp_filt,fs)
    pause
    
end