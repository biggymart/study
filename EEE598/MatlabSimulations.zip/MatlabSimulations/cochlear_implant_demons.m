clear
clc
close all
[xsig fs] = audioread('sa1.wav');
[xsig fs] = audioread('Track55.wav');
xsig = xsig(25000:7*fs)';


Nchannels = 16;
rnd_carrier = 0;

% greenwood function
x = [0:0.001:1];
a = 2.1;
K = 1;
A = 165.4;
f = A*(10.^(a*x) - K);
fmax = fs/2;
fmin = 250;
fprime = f(find(and(f>fmin,f<fmax)));

delf = floor(length(fprime)/Nchannels);
cf = fprime(1:delf: Nchannels*delf);


bw = 100;
Blpf = fir1(1024,[100]/(fs/2));


% nonlinear compression function
compress_function = @(xx)(10e-3)*((1./(1 + exp(-100*xx)))-0.5);
%plot([0:0.001:.2],compress_function([0:0.001:.2]))
nsc = [1:length(xsig)];


xrecon = zeros(length(xsig),1);
for i = 1:Nchannels
   B = fir1(1024,[(cf(i)-bw/2) (cf(i)+bw/2)]/(fs/2),'bandpass');
   
 
  xi = filter(B,1,xsig);
  xi_env = filter(Blpf,1,abs(xi));

  
   
 if rnd_carrier == 1
  rnd_car = filter(B,1,randn(length(xi_env), 1));
  xrecon = xrecon + xi_env.*rnd_car;
 else
   sin_car = sin(2*pi*(cf(i))/fs*nsc);
   xrecon = xrecon + xi_env.*sin_car';
 end
%   plot(xi_env.*sin_car')
  %soundsc(xrecon,fs)
%pause
  
  
  
end

disp('Playing Original');
soundsc(xsig, fs);

pause;

disp('Playing Coded');
soundsc(xrecon, fs);






fr_len = 100;        % 20 ms frame
fr_N = ((fr_len/1000)*fs);
shift_R = fr_N/5;
w = window(@hamming,fr_N);




[S,F,T,P] = spectrogram(xrecon,w,fr_N - shift_R,fr_N,fs);
figure
imagesc(T,F,20*log10(abs(S)));
axis xy
xlabel('Time (s)')
ylabel('Frequency (Hz)');

[S,F,T,P] = spectrogram(xsig,w,fr_N - shift_R,fr_N,fs);
figure
imagesc(T,F,20*log10(abs(S)));
axis xy
xlabel('Time (s)')
ylabel('Frequency (Hz)');


