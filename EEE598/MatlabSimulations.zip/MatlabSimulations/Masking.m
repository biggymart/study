clear
clc



ET = 60;
f = 1000;

if f<=1500
    g = 13*atan(0.76*f/1000)+ 3.5*atan(f/7500)^2;
else
    g = 8.7 + 14.2*log10(f/1000);
end

b = [0.1:0.1:24];

Sm = inline('15.81 + 7.5*(x+0.474)-17.5*sqrt(1 + (x+0.474).^2)','x');


TN1 = ET - 2.025 - 0.17*g + Sm(b-g);



ET2 = 70;
f = 1200;

if f<=1500
    g = 13*atan(0.76*f/1000)+ 3.5*atan(f/7500)^2;
else
    g = 8.7 + 14.2*log10(f/1000);
end

b = [0.1:0.1:24];

Sm = inline('15.81 + 7.5*(x+0.474)-17.5*sqrt(1 + (x+0.474).^2)','x');


TN2 = ET - 2.025 - 0.17*g + Sm(b-g);


TN = log10(10.^(TN1) + 10.^(TN2));

plot(b, TN1); hold on; plot(b, TN2); hold on; plot(b, TN);

