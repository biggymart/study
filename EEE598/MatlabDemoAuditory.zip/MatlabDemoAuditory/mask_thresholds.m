clear
clc
close all

f = [50:0.1:15000];
Tq = 3.64*(f/1000).^(-0.8) - 6.5*exp(-0.6*(f/1000 - 3.3).^2) + 10^(-3) *(f/1000).^4;


z1 = 13*atan(0.76*f(f<=1500)/1000) + 3.5*atan(f(f<=1500)/7500).^2;
z2 = 8.7 + 14.2*log10(f(f>1500)/1000);
z = [z1 z2];

plot(f,z)

subplot(211)
plot(f,Tq)
subplot(212)
plot(z,Tq);
keyboard


fs = 22050;
n = [1:1:fs*2];

f_v = [200 500 1000 1100 2000 ];
L_v = [20 55 57 40 52];


PN = 90.302;
L_v_i = (10.^((L_v - PN)/10))*length(n);


[mask_thresh,GMT] = masking_threshold(f_v, L_v, z,Tq);

sig = zeros(length(n),1);

sig2 = zeros(length(n),1);

for i = 1:length(f_v)
    if i ~=4
      sig2 = sig2+ L_v_i(i)*cos(2*pi*(f_v(i)/fs).*n)';
    end
    
    sig = sig+ L_v_i(i)*cos(2*pi*(f_v(i)/fs).*n)';
    
    
    if f_v(i)<1500;
        z_v(i) = 13*atan(0.76*f_v(i)/1000);
    else
        z_v(i) = 8.7 + 14.2*log10(f_v(i)/1000);
    end
end

figure(1)

stem(z_v, L_v,'k')
pause
ylim([0 100])
hold on
plot(z,mask_thresh','--')
pause
plot(z,GMT);
pause
plot(z,Tq,'k--')
hold off


% 
% JND = zeros(1,length(f));
% for i = 1:25
%     JND(and(z>(i-1), z<(i))) = min(GMT(and(z>(i-1), z<(i))));
% end
% 
% figure(2)
% stem(z_v, L_v,'k')
% ylim([0 100])
% hold on
% plot(z,JND)
% 
