clear
clc

%function mask(f,A)
% % % % % % %
%MASK Performs a simple psychoacoustic masking test by creating bandlimited noise around 1000 Hz and a single sinusoid at frequency f with amplitude A. It then plays the noise alone, and then the noise plus the sinusoid.
%f - frequency of sinusoid (0 to 11025) A - amplitude of sinusoid (0 to 1)
%Set sampling rate to 22050 Hz
%
fs = 22050;
f = 1000;
 

Aall = [0.001, 0.01 0.02 0.05 10];

for i = 1:length(Aall)
    A = Aall(i);
    [b,a] = butter(4,[0.08 0.1]);


    wn = rand(1,22050);
    % Filter the white noise with our filter
    wf = filter(b,a,wn);
    % By filtering, we've reduced the power in the noise, so we normalize: 
    wf = wf/max(abs(wf));



    % Create the sinusoid at frequency f, with amplitude A: 
    s = A*cos(2*pi*3000/fs*[0:fs-1]);
    % Play the sounds


%     sound(wf,22050)
%     pause % Pause for one second between sounds 
%     soundsc(wf+s,22050)
    plot(wf+s)
    pause;
end
