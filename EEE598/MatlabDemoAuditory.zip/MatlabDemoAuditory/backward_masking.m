
clear
clc

%function mask(f,A)
% % % % % % %
%MASK Performs a simple psychoacoustic masking test by creating bandlimited noise around 1000 Hz and a single sinusoid at frequency f with amplitude A. It then plays the noise alone, and then the noise plus the sinusoid.
%f - frequency of sinusoid (0 to 11025) A - amplitude of sinusoid (0 to 1)
%Set sampling rate to 22050 Hz
%
fs = 22050;
f1 = 1000;

f2 = 1000;

t1 = 10/1000;
n1 = floor(t1*fs);
A1 = .05;


t2 = 200/1000;
n2 = floor(t2*fs);
A2 = 1;


t3 = 10/1000;
n3 = floor(t3*fs);

s3 = zeros(1,n3);


% Create the sinusoid at frequency f, with amplitude A: 
s1 = A1*cos(2*pi*f1/fs*[1:n1]);
s2 = A2*cos(2*pi*f2/fs*[1:n2]);
soundsc([s1 s3 s2], fs)   