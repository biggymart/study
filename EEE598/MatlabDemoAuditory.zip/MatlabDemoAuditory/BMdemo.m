clear
clc
close all

addpath gammaTone;

fs = 44100;
f = 1000;
n = [1:20000];
Ndet = 200;

[forward,feedback,cf,ERB,B]=GammaToneMake(fs,Ndet,100,20000,'lyon');

x = 1*cos(2*pi*15000/fs*n)  + .5*cos(2*pi*2000/fs*n)+ 0.5*cos(2*pi*1000/fs*n) + 1*cos(2*pi*(800)/fs*n);

[y] = GammaToneApply(x,forward,feedback);

BM = mean(abs(y(:,:)'));
bm_x = linspace(0,3.5,Ndet);

plot(bm_x,BM(end:-1:1))
xlabel('Distance along basilar membrane (cm)');


% 
% x = audioread('sa1.wav');
% 
% x = x(1.28e4:1.44e4);
% x = resample(x,441,160);
% 
% [y] = GammaToneApply(x,forward,feedback);
% 
% BM = mean(abs(y(:,:)'));
% bm_x = linspace(0,3.5,Ndet);
% 
% figure(1)
% subplot(211)
% plot(bm_x,BM(end:-1:1))
% xlabel('Distance along basilar membrane (cm)');
% 
% 
% 
% x = audioread('sa1.wav');
% x = x(1.6e4:1.8e4);
% x = resample(x,441,160);
% 
% [y] = GammaToneApply(x,forward,feedback);
% 
% BM = mean(abs(y(:,:)'));
% bm_x = linspace(0,3.5,Ndet);
% figure(1)
% subplot(212)
% plot(bm_x,BM(end:-1:1))
% xlabel('Distance along basilar membrane (cm)');
% 
