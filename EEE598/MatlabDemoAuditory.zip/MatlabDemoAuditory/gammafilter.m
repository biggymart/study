%gammatone filter
clear
clc

[x fs] = audioread('sa1.wav');
x = resample(x, 221,160);
fs = 22100;

fcall = [50 150 250 350 450 570 700 840 1000 1170 1370 1600 1850 2150 2500 2900 3400 4000 4800 5800 7000 8500 10500]; 

N = 1000;
n = [1:1:N];
a = 0.1;
b = 1;
fc = 3400;


 
%fs = 22050;
T = 1/fs;
f = linspace(1,fs/2, N/2);

for i = 1:length(fcall)
    fc = fcall(i);
    ERB = 24.7*(4.37*(fc/1000) + 1);
    g = (n*T).^(2).*exp(-2*pi*b*ERB*n*T).*cos(2*pi*fc*n*T);
    Gabs = abs(fft(g));

    plot(f,20*log10((1/max(Gabs))*Gabs(1:end/2)))
    g_nogain(i,:) = ifft((1/max(Gabs))*fft(g));
    
    
    hold on
    
end



xfilt = conv(x, g_nogain(7,:));

soundsc(xfilt, fs)


