%DECODER PORTION

function synth_speech = f_DECODER (aCoeff, pitch_plot, voiced, gain);


%re-calculating frame_length for this decoder,
frame_length=1;
for i=2:length(gain)
    if gain(i) == 0,
        frame_length = frame_length + 1;
    else break;
    end
end

%decoding starts here,
for b=1 : frame_length : (length(gain)),    %length(gain) should be very close 
                                            %(i.e less than a frame_length error) to length(x)
    
    %FRAME IS VOICED OR UNVOICED
    if voiced(b) == 1,   %voiced frame
            pitch_plot_b = pitch_plot(b);
        syn_y1 = f_SYN_V (aCoeff, gain, frame_length, pitch_plot_b, b);
    else syn_y1 = f_SYN_UV (aCoeff, gain, frame_length, b); %unvoiced frame
    end
    
    synth_speech(b:b+frame_length-1) = syn_y1;
end


%% a function of f_DEOCDER
% clear all;
% frame_length = 480;
% pitch_plot_b = 92;

function syn_y1 = f_SYN_V (aCoeff, gain, frame_length, pitch_plot_b, b);

%creating pulsetrain;
for f=1:frame_length
    if f./pitch_plot_b == floor(f./pitch_plot_b)
        ptrain(f) = 1;
    else ptrain (f) = 0;
    end
end

syn_y2 = filter(1, [1 aCoeff((b+1):(b+1+9))], ptrain);
syn_y1 = syn_y2 .* gain(b);

%% a function of f_DEOCDER

function syn_y1 = f_SYN_UV (aCoeff, gain, frame_length, b);

wn = randn(1, frame_length);
syn_y2 = filter(1, [1 aCoeff((b+1):(b+1+9))], wn);
syn_y1 = syn_y2 .* gain(b);