function plot_fft(x,Fs,ps)

NFFT = length(x);
%scal = NFFT/length(x);
% what is that for?
Y = fft(x,NFFT)/NFFT;
f = Fs/2*linspace(0,1,NFFT/2+1);
figure
if ps ==1
    plot(f,20*log10(abs(Y(1:floor(NFFT/2)+1))))
    title('Single-Sided Power Spectrum of Signal')
    xlabel('Frequency (Hz)')
    ylabel('Signal Power')
else
    plot(f,2*abs(Y(1:floor(NFFT/2)+1)))
    title('Single-Sided Amplitude Spectrum of Signal')
    xlabel('Frequency (Hz)')
    ylabel('Signal Amplitude')
end
