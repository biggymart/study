clear
clc

f = 500;
fs = 8000;

w = 2*pi*f/fs;
len = 2;

n =[1:fs*len];

t = n/fs;

x= cos((2*pi*f/fs)*n);
XX = 20*log10(abs(fft(x)));

plot(XX)


delw = (2*pi)/(fs*len);
w=n*delw;
plot(w,XX)


f = (w*fs)/(2*pi);
plot(f(1:len/2*fs),XX(1:len/2*fs))





x = .8*cos((2*pi*200/fs)*n) + 4*cos((2*pi*250/fs)*n)+ 3*cos((2*pi*350/fs)*n) + 4*cos((2*pi*600/fs)*n);
XX = abs(fft(x));
plot(f(1:len/2*fs),XX(1:len/2*fs))

plot(t, x)




[x, fs]=audioread('sa1.wav');

t = [1:length(x)]/fs;
f = linspace(0, fs, length(x));

plot(t, x)

XX = abs(fft(x));
plot(f(1:length(x)/2),XX(1:length(x)/2))
