function y=filter_bpf(x,Fs,c1,c2)

% Max filter tap length is 512
N = min(round(length(x)/10),512);


if or(c1 > Fs/2, c2 > Fs/2)
    disp('ERROR: One (or both) of your cutoff frequencies are greater than half the sampling rate');
    return;
end

if c1 >= c2
    disp('ERROR: Remember that the upper cutoff frequency (c2) has to be greater than the lowe cutoff frequency (c1)');
    return;
end

if c2 == (Fs/2)
    c2 = (Fs/2) -1;
end

if c1 == 0
    Wn = [c2]/(Fs/2);
    B = fir1(N,Wn);
else
    Wn = [c1 c2]/(Fs/2);
    B = fir1(N,Wn,'bandpass');
end

y = filter(B,1,x);
fdel = floor(N/2); 

y = y(fdel+1:end);
if size(y,2) > size(y,1)
    y = [y zeros(1,fdel)];
else
    y = [y;zeros(fdel,1)];
end

