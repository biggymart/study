% Clear and close everything
clear
clc
close all


% Read in a .wav file into a variable x. Its sampling rate is stored in the
% variable SR
%[x,SR] = wavread('sa1.wav');
[x,SR] = wavread('music.wav');
x = x /max(x);

% filter the speech signal in x with a bandpass filter
y = filter_bpf(x,SR,0,1000);

% plot the FT of the original signal x and the filtered signal y
plot_fft(x,SR,0);
plot_fft(y,SR,0);



% play the original signal x and the filtered signal y, with a pause in
% between
pause
soundsc(x,SR)
pause
soundsc(y,SR)

