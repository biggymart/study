clear
clc
close all

% Step-1: specify the sampling rate
SR = 3000;                    % Sampling frequency
time_bin = 1/SR;


% Step-2: define the parameters of the sine wave
duration = 2;                      % signal length in seconds
t = 0:time_bin:duration;                % Time vector


% Signal to Plot: Sum of sinusoids
x = .8*sin(2*pi*200*t);      % 4*sin(2*pi*250*t)+ 3*sin(2*pi*350*t)+ 2*sin(2*pi*370*t)+ 5*sin(2*pi*400*t); x = x/max(x);



% Plot the first 100 samples of the original signal and play it
disp('Original 32-bit version');
soundsc(x,SR)
plot(t(1:100),x(1:100))
pause 


% Quantize the signal with 16, 8, 4, and 2 bits, play it, and plot the 
% first 100 samples of the original signal with the quantized version
% overlayed
disp('16-bit quantized');
x_16bits = double(uencode(x,16))/(2^16);
x_16bits = 2*(x_16bits-mean(x_16bits));
soundsc(x_16bits,SR)
plot(t(1:100),x(1:100),t(1:100),x_16bits(1:100))
pause

disp('8-bit quantized');
x_8bits = double(uencode(x,8))/(2^8);
x_8bits = 2*(x_8bits-mean(x_8bits));
soundsc(x_8bits,SR)
plot(t(1:100),x(1:100),t(1:100),x_8bits(1:100))
pause

disp('4-bit quantized');
x_4bits = double(uencode(x,4))/(2^4);
x_4bits = 2*(x_4bits-mean(x_4bits));
soundsc(x_4bits,SR)
plot(t(1:100),x(1:100),t(1:100),x_4bits(1:100))
pause

disp('2-bit quantized');
x_2bits = double(uencode(x,2))/(2^2);
x_2bits = 2*(x_2bits-mean(x_2bits));
soundsc(x_2bits,SR)
plot(t(1:100),x(1:100),t(1:100),x_2bits(1:100))


% % FT Demo
% plot_fft(x_4bits,SR,1)
