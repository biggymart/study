clear
clc
close all

% Step-1: specify the sampling rate
SR = 8000;                    % Sampling frequency
time_bin = 1/SR;


% Step-2: define the parameters of the sine wave
duration = 2;                      % signal length in seconds


% Derived Parameters
%T = 1/Fs;                     % Sample time
%L = Fs*Ls;                     % Length of signal
t = 0:time_bin:duration;                % Time vector


% Signal to Plot: Sum of sinusoids
x = .8*sin(2*pi*1000*t+2.1) + 4*sin(2*pi*250*t); %+ 3*sin(2*pi*350*t)+ 2*sin(2*pi*370*t)+ 5*sin(2*pi*400*t); 



SR_2k = SR;
x_SR2k = resample(x,SR_2k,SR);
time_bin2k = 1/SR_2k;
t_2k = 0:time_bin2k:duration;               

t_2k = t;
x_SR2k = x;


plot(t(1:100), x(1:100));
hold on
stem(t_2k(1:round(100*SR_2k/SR)), x_SR2k(1:round(100*SR_2k/SR)),'r');
hold off
xlabel('time');
ylabel('Amplitude');
title('Sampling Rate: 8000 Hz');
sound(x_SR2k,SR_2k);



pause

SR_2k = 5000;
x_SR2k = resample(x,SR_2k,SR);
time_bin2k = 1/SR_2k;
t_2k = 0:time_bin2k:duration;               

plot(t(1:100), x(1:100));
hold on
stem(t_2k(1:round(100*SR_2k/SR)), x_SR2k(1:round(100*SR_2k/SR)),'r');
hold off
xlabel('time');
ylabel('Amplitude');
title('Sampling Rate: 5000 Hz');

sound(x_SR2k,SR_2k);

pause

SR_2k = 3000;
x_SR2k = resample(x,SR_2k,SR);
time_bin2k = 1/SR_2k;
t_2k = 0:time_bin2k:duration;               

plot(t(1:100), x(1:100));
hold on
stem(t_2k(1:round(100*SR_2k/SR)), x_SR2k(1:round(100*SR_2k/SR)),'r');
hold off
xlabel('time');
ylabel('Amplitude');
title('Sampling Rate: 3000 Hz');

sound(x_SR2k,SR_2k);


pause
SR_2k = 1500;
x_SR2k = resample(x,SR_2k,SR);
time_bin2k = 1/SR_2k;
t_2k = 0:time_bin2k:duration;



plot(t(1:100), x(1:100));
hold on
stem(t_2k(1:round(100*SR_2k/SR)), x_SR2k(1:round(100*SR_2k/SR)),'r');
hold off
xlabel('time');
ylabel('Amplitude');
title('Sampling Rate: 1500 Hz');

sound(x_SR2k,SR_2k);


% 
% 
% 
% disp('Original 32-bit version');
% sound(x,SR)
% pause 
% 
% disp('16-bit quantized');
% x_16bits = double(uencode(x,16))/(2^16);
% sound(x_16bits,SR)
% pause
% 
% disp('8-bit quantized');
% x_8bits = double(uencode(x,8))/(2^8);
% sound(x_8bits,SR)
% pause
% 
% disp('4-bit quantized');
% x_4bits = double(uencode(x,4))/(2^4);
% sound(x_4bits,SR)
% pause
% 
% disp('2-bit quantized');
% x_2bits = double(uencode(x,2))/(2^2);
% sound(x_2bits,SR)
% 
% 
% % 
% % 
% % plot_fft(x,SR);
% % 
% % 
% % % Pick the FFT spectrum and regenerate the signal with only a subset of the
% % % Fourier coefficients
% % 
% % for k = 1:5
% %     pick_fft(x,Fs,k)
% %     pause
% % end
