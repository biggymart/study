clear
clc
close all

% Step-1: specify the sampling rate
SR = 10000;                    % Sampling frequency
time_bin = 1/SR;


% Step-2: define the parameters of the sine wave
duration = 1;                      % signal length in seconds
t = 0:time_bin:duration;                % Time vector


% Signal to Plot: Sum of sinusoids
x = .8*sin(2*pi*200*t) + 4*sin(2*pi*250*t)+ 3*sin(2*pi*350*t)+ 2*sin(2*pi*370*t)+ 5*sin(2*pi*400*t)+ 3* 5*sin(2*pi*1000*t); 


y = filter_bpf(x,SR,225,300);



plot_fft(x,SR,0);
plot_fft(y,SR,0);

pause
soundsc(x,SR)
pause
soundsc(y,SR)




% 
% 
% plot_fft(x,SR);
% 
% 
% % Pick the FFT spectrum and regenerate the signal with only a subset of the
% % Fourier coefficients
% 
% for k = 1:5
%     pick_fft(x,Fs,k)
%     pause
% end
