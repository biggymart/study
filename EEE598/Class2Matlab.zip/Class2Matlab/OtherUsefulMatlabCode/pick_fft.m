function pick_fft(x,Fs,k)

T = 1/Fs;                     % Sample time
L = length(x);                     % Length of signal
t = (0:L-1)*T;                % Time vector

NFFT = length(x);
%scal = NFFT/length(x);
Y = fft(x,NFFT)/NFFT;
f = Fs/2*linspace(0,1,NFFT/2+1);


Y_zeros = zeros(1,NFFT/2+1);
Y_abs = abs(Y(1:NFFT/2+1));
[Y_abs_sort Y_abs_sort_idx] = sort(Y_abs,'descend');
Y_zeros(Y_abs_sort_idx(1:k)) = Y_abs_sort(1:k);

%T_per = f(Y_abs_sort_idx(1));
plot_len = min(L, 300);

%stem(Y_zeros)
Y_hat = [Y_zeros Y_zeros(NFFT/2:-1:2)];
y_hat = NFFT*ifft(Y_hat);


subplot(311)
plot(f,2*abs(Y(1:NFFT/2+1))) 
title('Single-Sided Amplitude Spectrum of y(t)')
xlabel('Frequency (Hz)')
ylabel('|Y(f)|')
subplot(312)
plot(f,2*abs(Y_zeros(1:NFFT/2+1))) 
title('Single-Sided Amplitude Spectrum of y(t)')
xlabel('Frequency (Hz)')
ylabel('|Y(f)|')
subplot(313)
plot(Fs*t(1:plot_len),x(1:plot_len))
hold on
plot(Fs*t(1:plot_len),y_hat(1:plot_len),'r')
hold off
