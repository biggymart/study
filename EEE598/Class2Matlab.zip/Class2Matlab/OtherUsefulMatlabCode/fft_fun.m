clear
clc


Fs = 16000;                    % Sampling frequency
T = 1/Fs;                     % Sample time
L = 16000;                     % Length of signal
t = (0:L-1)*T;                % Time vector

% Sum of a 50 Hz sinusoid and a 120 Hz sinusoid
x1 = 0.8*cos(2*pi*150*t); 

x2 = 0.8*cos(2*pi*4000*t); 

plot(Fs*t(1:50),x(1:50))


x_hat = fft_pick(x,L

NFFT = L;
Y = fft(x,NFFT)/L;
f = Fs/2*linspace(0,1,NFFT/2+1);
plot(f,2*abs(Y(1:NFFT/2+1))) 
title('Single-Sided Amplitude Spectrum of y(t)')
xlabel('Frequency (Hz)')
ylabel('|Y(f)|')



k = 1;
Y_zeros = zeros(1,NFFT/2+1);
Y_abs = abs(Y(1:NFFT/2+1));
[Y_abs_sort Y_abs_sort_idx] = sort(Y_abs,'descend');
Y_zeros(Y_abs_sort_idx(1:k)) = Y_abs_sort(1:k);
stem(Y_zeros)
Y_hat = [Y_zeros Y_zeros(NFFT/2:-1:2)];
y_hat = N*ifft(Y_hat);



figure
plot(Fs*t(1:50),x(1:50))
hold on
plot(Fs*t(1:50),y_hat(1:50),'r')
hold off
