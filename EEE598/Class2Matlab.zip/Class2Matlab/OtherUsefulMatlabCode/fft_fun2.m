clear
clc
close all


% User-defined Parameters
Fs = 1000;                    % Sampling frequency
Ls = 10;                      % signal length in seconds


% Derived Parameters
T = 1/Fs;                     % Sample time
L = Fs*Ls;                     % Length of signal
t = (0:L-1)*T;                % Time vector

% Signal to Plot: Sum of sinusoids
x = 5*cos(2*pi*10*t) + 4*cos(2*pi*30*t)+ 3*cos(2*pi*50*t)+ 2*cos(2*pi*70*t)+ 5*cos(2*pi*90*t); 

plot_fft(x,Fs);


% Pick the FFT spectrum and regenerate the signal with only a subset of the
% Fourier coefficients

for k = 1:5
    pick_fft(x,Fs,k)
    pause
end
