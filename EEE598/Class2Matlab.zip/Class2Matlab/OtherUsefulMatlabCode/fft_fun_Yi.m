clear
clc
close all

% Step-1: specify the sampling rate
SR = 3000;                    % Sampling frequency
time_bin = 1/SR;


% Step-2: define the parameters of the sine wave
duration = 2;                      % signal length in seconds


% Derived Parameters
%T = 1/Fs;                     % Sample time
%L = Fs*Ls;                     % Length of signal
t = 0:time_bin:duration;                % Time vector


% Signal to Plot: Sum of sinusoids
x = .8*sin(2*pi*200*t); % + 4*sin(2*pi*250*t)+ 3*sin(2*pi*350*t)+ 2*sin(2*pi*370*t)+ 5*sin(2*pi*400*t); 

sound(x,SR)
pause 

x_16bits = double(uencode(x,16))/(2^16);
sound(x_16bits,SR)

pause


x_8bits = double(uencode(x,8))/(2^8);
sound(x_8bits,SR)

pause

x_4bits = double(uencode(x,4))/(2^4);
sound(x_4bits,SR)

pause

x_2bits = double(uencode(x,2))/(2^2);
sound(x_2bits,SR)


% 
% 
% plot_fft(x,SR);
% 
% 
% % Pick the FFT spectrum and regenerate the signal with only a subset of the
% % Fourier coefficients
% 
% for k = 1:5
%     pick_fft(x,Fs,k)
%     pause
% end
