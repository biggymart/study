clear
clc


[x, fs] = audioread('sa2.wav');
len_x = length(x);
t = [1:len_x]/fs;
plot(t,x)
sound(x,fs)


% Averaging FIR filtering
M = 9;      % Length 9 averaging filter
b = (1/M)*ones(M,1);
disp(b)
y = conv(b,x);     % or y = filter(b,1,x)
soundsc(y,fs)         % you can also use soundsc(y,fs), however this rescales the speech signal

E_x = sqrt(sumsqr(x));
E_y = sqrt(sumsqr(y));

E_ratio = E_y/E_x

subplot(211)
plot(x)
title("Original")
subplot(212)
plot(y)
title("Average Filtered")


%%% Linear Time Invariance %%%%

% Time shift
% We introduce one second of silence in the signal x
y = conv(b,x);
x_shifted = [zeros(fs,1); x];
y_shifted = conv(b,x_shifted);

subplot(311)
plot([zeros(fs,1); y])
title("Avg filtered and then shifted")
subplot(312)
plot(y_shifted)
title("Shifted and then avg filtered")
subplot(313)
plot(y_shifted - [zeros(fs,1); y]);
title("The difference")


% Superposition
[x2 fs2] = audioread('sa1.wav');
sound(x2, fs2)   % "She had your dark suit in greasy wash water all year."
y2 = conv(b,x2(1:2*fs));
y = conv(b,x(1:2*fs));

x_sp = x(1:2*fs) + x2(1:2*fs);
y_sp = conv(b,x_sp);

subplot(311)
plot(y2 + y);
title("Each avg filtered and then superpositioned")
subplot(312)
plot(y_sp)
title("Superpositioned and then avg filtered")
subplot(313)
plot(y_sp - (y2+y));
title("The difference")

sound(y2 + y, fs)
sound(y_sp, fs)
sound(y_sp - (y2+y), fs)

% Scaling
x_scal = 1.5*x;
y_scal = conv(b,x_scal);
y = conv(b,x);

subplot(311)
plot(1.5*y);
title("Avg filtered and then scaled")
subplot(312)
plot(y_scal)
title("Scaled and then avg filtered")
subplot(313)
plot(y_scal - 1.5*y)
title("The difference")


% Changing the order of LTI systems
M1 = 9;      % Length 9 averaging filter
b1 = (1/M1)*ones(M1,1);

M2 = 3;      % Length 3 averaging filter
b2 = (1/3)*ones(3,1);

y12 = conv(b2,conv(b1,x));

y21 = conv(b1,conv(b2,x));

y1122 = conv(conv(b1,b2),x);

subplot(411)
plot(y12)
title("Filter with b1 and then with b2: y12")
subplot(412)
plot(y21)
title("Filter with b2 and then with b1: y21")
subplot(413)
plot(y12-y21)
title("The difference btwn y12 and y21")
subplot(414)
plot(y12-y1122)
title("The difference btwn y12 and y1122")



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Plotting the frequency response of the filter
w = linspace(0,pi,1024);
H = freqz(b,1,w);
subplot(211)
plot(w,abs(H))
subplot(212)
plot(w,20*log10(abs(H)))


b = fir1(150, 1/8,'high');
w = linspace(0,pi,1024);
H = freqz(b,1,w);
subplot(211)
plot(w,abs(H))
subplot(212)
plot(w,20*log10(abs(H)))













