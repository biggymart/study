clear
clc
close all
[x SR] = audioread('sa1.wav');
x = 3*x;

% Plot the first 100 samples of the original signal and play it
disp('Original 16-bit version');
soundsc(x,SR)
t = [1:length(x)]/SR;
figure(1);
plot(t(12500:13000),x(12500:13000));
pause;


disp('2-bit quantized');
figure(2);
x_2bits = double(uencode(x,2))/(2^2);
x_2bits = 2*(x_2bits-mean(x_2bits));
soundsc(x_2bits,SR)
subplot(211)
plot(t(12500:13000),x(12500:13000),t(12500:13000),x_2bits(12500:13000))
subplot(212)
plot(x(12500:13000) - x_2bits(12500:13000))
pause;

% % FT Demo
% plot_fft(x_4bits,SR,1)
