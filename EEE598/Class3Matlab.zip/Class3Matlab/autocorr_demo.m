clear
clc

fs = 5000;       % sampling freq == 5000
len = 3;         % length of audiofile == 3 sec
t = [1:len*fs];  % total of 15000 samples

x = 0.5*sin(2*pi*(400/fs)*t);
x_v = x(1:200);

sound(x,fs)

aco= [];
for i = 1:400
    sig1 = x_v(1:end-((i-1)*1));
    sig2 = x_v(((i-1)*1)+1:end);
    
    subplot(211)
    plot(sig1)
    hold on
    plot(sig2,'r')
    hold off
    aco(i) = sum(sig1.*sig2);
    subplot(212)
    plot(aco)
    
    pause(0.01)
    
end

keyboard


x_v = randn(200,1);

%sound(x,fs)

aco= [];
for i = 1:100
    sig1 = x_v(1:end-((i-1)*1));
    sig2 = x_v(((i-1)*1)+1:end);
    
    subplot(211)
    plot(sig1)
    hold on
    plot(sig2,'r')
    hold off
    aco(i) = sum(sig1.*sig2);
    subplot(212)
    plot(aco)
    
    pause(0.05)
    
end

