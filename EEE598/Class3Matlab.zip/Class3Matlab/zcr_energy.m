clear
clc

[x fs] = audioread('sa1.wav');
fr_len = 20;        % 20 ms frame
sound(x,fs);

fr_N = ((fr_len/1000)*fs);
shift_R = fr_N/2;

E = [];
zcr = [];

for i = 1:shift_R:(length(x)-fr_N)
    n=[i:i+fr_N-1];
    
    w = window(@hamming,fr_N);
    xwin = (x(n).^2).*w;
    xwin2 = x(n);

    E(end+1) = sum(xwin);
    zcr(end+1) = sum(xwin2(1:end-1).*xwin2(2:end)<0);
    
end

figure
plot(x/max(x))
hold on
plot([1:shift_R:(length(x)-fr_N)],E/max(E),'r')
plot([1:shift_R:(length(x)-fr_N)],zcr/max(zcr),'k')

legend('Speech', 'Energy', 'ZCR');

% 
%  [S,F,T,P] = spectrogram(x,w,shift_R);
% figure
% imagesc(T,F,20*log10(abs(S)));
% axis xy
