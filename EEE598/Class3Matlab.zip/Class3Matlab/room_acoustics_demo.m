clear
clc
close all


[x fs] = wavread('sa1.wav');

sos = 340.29;           % speed of sound: 340.29 m/s

d1 = 10;
a1 = 0.8;
t1 = d1/sos;
n1 = t1*fs;

d2 = 20;
a2 = 0.1;
t2 = d2/sos;
n2 = t2*fs;

d3 = 5;
a3 = 0.3;
t3 = d3/sos;
n3 = t3*fs;

% room transfer function - this is just a filter
h = zeros(1000,1);
h(1) = 1;
h(floor(n1)) = a1;
h(floor(n2)) = a2;
h(floor(n3)) = a3;

x_rev = filter(h,1,x);


soundsc(x_rev, fs)


plot(autocorr(x_rev,1000))
hold on
stem(h,'r')
hold off


soundsc(x,fs)
pause
soundsc(x_rev,fs)



% IIR Filter
% Inverse filtering - removing reverberation
xp = filter(1,h,x_rev);
soundsc(xp,fs);




