clear
clc
close all


[x fs] = audioread('sa1.wav');
fr_len = 20;        % 20 ms frame
fr_N = ((fr_len/1000)*fs);
shift_R = 0.25*fr_N;

sum_w = zeros(11*fr_N,1);

figure(1)
hold on
for i = 1:shift_R:10*fr_N
    n=[i:i+fr_N-1];
    
    w = window(@triang,fr_N);
    %w = window(@hamming,fr_N);
   % w = window(@rectwin,fr_N);
    
    sum_w(n) = sum_w(n) + w;
    
    
end

plot(sum_w)
pause


figure(2)
sum_w = zeros(100*fr_N,1);

for i = 1:shift_R:99*fr_N
    n=[i:i+fr_N-1];
    
    w = window(@triang,fr_N);
    xwin = x(n).*w;
        
   
    sum_w(n) = sum_w(n) + xwin;
end

plot(sum_w)