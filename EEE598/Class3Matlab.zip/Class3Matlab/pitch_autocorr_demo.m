clear
clc

[x fs] = audioread('sa1.wav');

x_v = x(33920:34650);       % voiced speech segment
plot(x_v)



% Autocorrelation
aco= [];
for i = 1:500
    sig1 = x_v(1:end-((i-1)*1));
    sig2 = x_v(((i-1)*1)+1:end);
    
    subplot(211)
    plot(sig1)
    hold on
    plot(sig2,'r')
    hold off
    aco(i) = sum(sig1.*sig2);
    subplot(212)
    plot(aco)
    
    pause(0.01)
    
end

%plot(xcorr(x_v(1:500))) . % or you can just use the built-in Matlab function to compute the autocorrelation

% AMDF

amdf= [];
for i = 1:500
    sig1 = x_v(1:end-((i-1)*1));
    sig2 = x_v(((i-1)*1)+1:end);
    
    subplot(211)
    plot(sig1)
    hold on
    plot(sig2,'r')
    hold off
    amdf(i) = mean(abs(sig1- sig2));
    subplot(212)
    plot(amdf)
    
    pause(0.01)
    
end
    




% clipped voiced speech segment - keep 70% of values
x_vclip = x_v;
x_vclip(and(x_v<0.5*max(x_v),x_v>0)) = 0;
x_vclip(and(x_v>-0.5*max(-x_v),x_v<0)) = 0;

plot(x_vclip)


aco= [];
for i = 1:500
    sig1 = x_vclip(1:end-((i-1)*1));
    sig2 = x_vclip(((i-1)*1)+1:end);
    
    subplot(211)
    plot(sig1)
    hold on
    plot(sig2,'r')
    hold off
    aco(i) = sum(sig1.*sig2);
    subplot(212)
    plot(aco)
    
    pause(0.01)
    
end
    

amdf= [];
for i = 1:500
    sig1 = x_vclip(1:end-((i-1)*1));
    sig2 = x_vclip(((i-1)*1)+1:end);
    amdf(i) = mean(abs(sig1 - sig2));
    
    
    subplot(211)
    plot(sig1)
    hold on
    plot(sig2,'r')
    hold off
    
    subplot(212)
    plot(amdf)
    
    pause(0.01)
    
end

