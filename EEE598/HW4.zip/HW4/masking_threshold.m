function [mask_thresh,GMT] = masking_threshold(f_vv, L_vv, z,Tq)
% masking threshold function given in class notes
s_l = 27;
for i = 1:length(f_vv)

    f_v = f_vv(i);
    L_v = L_vv(i);
    
    if f_v<1500;
        z_v = 13*atan(0.76*f_v/1000);
    else
        z_v = 8.7 + 14.2*log10(f_v/1000);
    end


    s_r = -24 - (230/f_v) + 0.2*L_v;

    b = [1:0.1:25];

    m_th = s_l*(z(z<=z_v)-z_v) + L_v;
    m_th2 = s_r*(z(z>z_v)-z_v) + L_v;

    mask_thresh(i,:) = [m_th m_th2]-6.025;
end

% get gmt values and return
GMT = zeros(1, size(mask_thresh,2));

for i = 1:length(f_vv)
    GMT = GMT + 10.^((1/10)*mask_thresh(i,:));
end
GMT = GMT + 10.^((1/10)*Tq); 

GMT = 10*log10(GMT);


