%% Homework 4
% This contains the functions used for each problem.
% Can run each problem separately as a section or the entire assignment.

%% Problem 1
close all ; clear all ; clc
disp("Running number 1...")
run hw4_1.m

%% Problem 2
close all ; clear all ; clc
disp("Running number 2...")
hw4_2('./HW4audio/sa1-fem.wav','./audio_out/fem_lf_7.wav',1,7)
title("Female - LF - 8 coeffs")
clear all ; clc ;

hw4_2('./HW4audio/sa1-fem.wav','./audio_out/fem_nolf_7.wav',0,7)
title("Female - NO LF - 8 coeffs")
clear all ; clc ;

hw4_2('./HW4audio/sa1-fem.wav','./audio_out/fem_lf_15.wav',1,15)
title("Female - LF - 16 coeffs")
clear all ; clc ;

hw4_2('./HW4audio/sa1-fem.wav','./audio_out/fem_nolf_15.wav',0,15)
title("Female - NO LF - 16 coeffs")
clear all ; clc ;

hw4_2('./HW4audio/sa1-mal.wav','./audio_out/mal_lf_7.wav',1,7)
title("Male - LF - 8 coeffs")
clear all ; clc ;

hw4_2('./HW4audio/sa1-mal.wav','./audio_out/mal_nolf_7.wav',0,7)
title("Male - NO LF - 8 coeffs")
clear all ; clc ;

hw4_2('./HW4audio/sa1-mal.wav','./audio_out/mal_lf_15.wav',1,15)
title("Male - LF - 16 coeffs")
clear all ; clc ;

hw4_2('./HW4audio/sa1-mal.wav','./audio_out/mal_nolf_715.wav',0,15)
title("Male - NO LF - 16 coeffs")
clear all ; clc ;