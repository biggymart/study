close all ; clear all; clc

% Bark scale components set-up
f = [50:0.1:15000];
z1 = 13*atan(0.76*f(f<=1500)/1000) + 3.5*atan(f(f<=1500)/7500).^2;
z2 = 8.7 + 14.2*log10(f(f>1500)/1000);
z = [z1 z2];

% Generate two sinusoids 400Hz and 2000Hz
fs = 22050;
N = fs * 2;

s1 = gen_sin(fs, 2,  400, 1);
s2 = gen_sin(fs, 2,  2000, 1);

% reduce the bit rates of each sinusoid to 12, 8, 4, 2 bps

% Set up a figure.
figure

% Set up arrarys for input data.
bps_ls = [2, 4, 8, 12];

% Let's do s1 first
sig = s1;
% First get the GMT of the original signal
[~, GMT] = getGMT(50, 15000, sig, N, fs);

subplot(211);
hold on

plot(z,GMT);
title('GMT')
xlabel('Frequency (Bark)')
ylabel('dB SPL')

for j = [1:length(bps_ls)]
    bps = bps_ls(j);
    quantized_sig = quant(sig, bps);
    
    % Calulate the quantization error.
    % Find the frequency component by fft.
    % Convert to Bark scale. (x-axis)
    q_e = sig - quantized_sig;
    q_e_freq = findfreq(q_e, N,fs); % e.g. 3250
    q_e_bark = freq2bark(q_e_freq); % e.g. 15.9687
    
    % Also convert amplitude into dB SPL. (y-axis)
    q_e_dbaspl = amp2dbspl(q_e, fs);

    % quantization overlay
    stem(q_e_bark, q_e_dbaspl)
end
legend("orig signal (16bps)","2bps quant. error","4bps quant. error","8bps quant. error","12bps quant. error")
hold off
% end of s1

% Let's do s2 now
sig = s2;
% First get the GMT of the original signal
[~, GMT] = getGMT(50, 15000, sig, N, fs);

subplot(212);
hold on

% plot the GMT
plot(z,GMT);
title('GMT')
xlabel('Frequency (Bark)')
ylabel('dB SPL')

for j = [1:length(bps_ls)]
    bps = bps_ls(j);
    quantized_sig = quant(sig, bps);
    
    % Calulate the quantization error.
    % Find the frequency component by fft.
    % Convert to Bark scale. (x-axis)
    q_e = sig - quantized_sig;
    q_e_freq = findfreq(q_e, N,fs); % e.g. 3250
    q_e_bark = freq2bark(q_e_freq); % e.g. 15.9687
    
    % Also convert amplitude into dB SPL. (y-axis)
    q_e_dbaspl = amp2dbspl(q_e, fs);

    % quantization overlay
    stem(q_e_bark, q_e_dbaspl)
end
legend("orig signal (16bps)","2bps quant. error","4bps quant. error","8bps quant. error","12bps quant. error")
hold off

% ** FUNCTIONS **
% 1. First function: Generate sinusoid
function sinusoid = gen_sin(fs, dur, freq, amp)
% fs: Sampling frequency (Hz).
% dur: Signal duration (second).
% freq: Sinusoid frequency.
% amp: Sinusoid Amplitude.

fs = fs; % Sampling frequency (Hz)
duration = dur; % Signal duration (second)

N = fs * duration; % Total number of samples
t = 0:1/fs:duration-1/fs; % Time vector

% Parameters
f = freq;
a = amp;

% Sinusoid signals
sinusoid = a * cos(2*pi*f*t);
end


% 2. Second function: Quantization
function quantized_sig = quant(signal, bps)
% signal: Signal to be quantized.
% bps: Desired bps. (above 2; e.g. 2, 4, 8, 12)

tmp = double(uencode(signal,bps))/(2^bps); % Let's play around with this part
quantized_sig = 2*(tmp-mean(tmp));
end


% 3. Third function: Find frequency component from fft
function Maxfreq = findfreq(signal, N, fs)
    % This function only finds one maximum frequency.
    % Only because we know that we are using simple sinusoid.
    % signal in time-domain
    % N: Total number of samples
    % fs: Sampling rate.
    
    S = fft(signal);
    S_oneSide = S(1:N/2); % eliminate the right-hand side
    freq = fs*(0:N/2-1)/N; % change the x-axis from sample index to frequency
    S_meg = abs(S_oneSide)/(N/2);
    
    max_amplitude = -inf;
    max_frequency = -1;
    
    for i = 1:length(freq)
        if S_meg(i) > max_amplitude
            max_amplitude = S_meg(i);
            max_frequency = (i-1)/2;
        end
    end
    
    Maxfreq = max_frequency;
end


function bark = freq2bark(f)
    % Frequency to Bark conversion
    % f: signal frequency
    if f <=1500
        bark = 13*atan(0.76*f/1000) + 3.5*atan(f/7500).^2;
    else
        bark = 8.7 + 14.2*log10(f(f>1500)/1000);
    end
end


function dbspl = amp2dbspl(signal, fs)
    % Convert Amplitude to dB SPL.
    % signal: Sound signal.
    % fs: Sampling rate

    % Normalization term. 
    % Formula: PN + 10*log(windowing * DFT).^2
    PN = 90.302;
    
    % windowing and fft
    % arbitrary length of frame maybe 20ms
    fr_len = 20;
    fr_N = ((fr_len/1000)*fs); 
    shift_R = fr_N; % No overlap
    
    sum_w = zeros(length(signal),1);
    
    for i = 1:shift_R:length(signal)
        n=[i:i+fr_N-1];
    
        w=window(@hamming, fr_N);
        xwin=signal(n)'.*w;
    
        sum_w(n) = sum_w(n)+xwin;
    end
    
    tmp = sum(sum_w);
    tmp = abs(tmp);
    tmp = tmp.^2;
    tmp = 10*log(tmp);
    
    dbspl = PN + tmp;
end


function [mask_thresh, GMT] = getGMT(low_edge, high_edge, signal, N, fs)
% low_edge: Lowest frequency that is in concern (e.g. 50)
% high_edge: Highest frequency that is in concern (e.g. 15,000)
% signal: Signal to find GMT.
% N: Total number of samples (e.g. duration * fs).
% fs: Sampling rate.

% Tq: Threshold in quiet. Known by research result.
f = [low_edge:0.1:high_edge];
Tq = 3.64*(f/1000).^(-0.8) - 6.5*exp(-0.6*(f/1000 - 3.3).^2) + 10^(-3) *(f/1000).^4;

% Bark scale components
z1 = 13*atan(0.76*f(f<=1500)/1000) + 3.5*atan(f(f<=1500)/7500).^2;
z2 = 8.7 + 14.2*log10(f(f>1500)/1000);
z = [z1 z2];

% find f_v
f_v = findfreq(signal, N, fs);

% find L_v (in dB SPL)
L_v = amp2dbspl(signal, fs);

% With all the given inputs, calculate masking threshold and GMT.
[mask_thresh, GMT] = masking_threshold(f_v, L_v, z, Tq);
end
