% Homework 4 Number 2

function [] = hw4_2(audio_file,name_output,LF_model,M_LPC)

    [x fs1] = audioread(audio_file);

    figure
    % plot the spectrogram of the original signal
    spectrogram(x);
    title("Original Audio File")
    xlabel("Time")
    ylabel("Frequency")
    
    fs = fs1;

    fr_len = 10;        % 10 ms frame
    fr_N = ((fr_len/1000)*fs);
    shift_R = fr_N/2;

    % ------------------------------------------------------

    % 2. 4. voicing and f0
    wdw_len = round(0.01*fs); % 10 ms window
    overlap_len = round(0.005*fs); % 5 ms overlap
    f0 = pitch(x, fs, Range=[50,250],Method="SRH",WindowLength=wdw_len,OverlapLength=overlap_len);

    % Distinguish between silence and speech
    thresh_energy = 0.01;
    [frames, ~] = buffer(x, wdw_len, overlap_len, "nodelay");
    % calculate the energy of the frames by multiplying by a window to reduce
    % edge effects and takes the square root to get the energy (i.e. parsevals)
    eng_frames = sum((frames.*hamming(wdw_len,"periodic")).^2,1);
    speech_vals = eng_frames(:) > thresh_energy;

    % Distinguish between voiced and unvoiced
    % A large number of zero crossings implies that there is no dominant low-frequency oscillation. 
    % If the zero crossing rate for a frame is below a given threshold, you declare it as voiced.
    zcr_thresh = 0.2;
    zcr = zerocrossrate(x,WindowLength=wdw_len,OverlapLength=overlap_len);
    voiced_vals = zcr < zcr_thresh;

    % Combine speech and voiced_vals to determine whether a frame contains voiced speech.
    voicedSpeech = speech_vals & voiced_vals;

    % Remove regions that do not correspond to voiced speech from the pitch estimate and plot.
    f0(voicedSpeech) = NaN;

    % ------------------------------------------------------

    sum_w = zeros(160*fr_N,1);

    for i = 1:shift_R:159*fr_N

        % use pitch values found to create glottal pulse at that frequency
        if ~isnan(f0(round(i/fr_N)+1))
            pf = f0(round(i/fr_N)+1);
        else
            pf = 1;
        end

        gp = [];
        gp_period = 0;
        gp = sin(2*pi*(pf/fs).*[1:length(x)])';
        gp(gp<0) = 0;
        
        gp_period = floor(fs/pf);
        gp = sin(2*pi*(pf/fs).*[1:gp_period])';
        gp(gp<0) = 0;
        
        
        gp_cum = [];
        for j = 1:ceil(length(x)/gp_period)
            gp_cum = [gp_cum;gp];
            gp_cum = [gp_cum; zeros(round(10*rand),1)];
        end

        % We take a derivative of the gottal flow waveform to get to the glottal
        % flow derivative. This is the input to the Source/Filter model:
        if LF_model
            e = diff(gp_cum);  % LF Model
            e = e+0.01*randn(length(e),1); 
        else
            e = 0.01*randn(64010,1); 
        end

        % get vector of e_temp based on voiced speech values
        if voicedSpeech(round(i/fr_N)+1)
            e_temp = e;
        else
            e_temp = wgn(57989,1,sumsqr(e));
        end

        % create frame values
        n=[i:i+fr_N-1];
        
        w = window(@triang,fr_N);
        xwin1 = x(n).*w;
        
        [A1] = lpc(xwin1,M_LPC);

        % Decoder portion

        % use lpc values to generate filter to save into decoder
        E1 = filter(A1,1,xwin1);
        
        E2 = e_temp([i:i+fr_N-1]).*w;
        
        g = sumsqr(E1)/sumsqr(E2);
        xwin1_recon = filter(1,A1,sqrt(g)*E2);
        
        sum_w(n) = sum_w(n) + xwin1_recon;
    end

    figure
    % Plot spectrum of output
    spectrogram(sum_w);
    xlabel("Time")
    ylabel("Frequency")

    % soundsc(sum_w,fs)

    % save the sound file as wav
    audiowrite(name_output,sum_w,fs)
end