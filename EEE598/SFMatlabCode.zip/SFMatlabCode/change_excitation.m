clear
clc


[x1 fs1] = audioread('SteveJob.wav');


fs = fs1;

fr_len = 20;        % 20 ms frame
fr_N = ((fr_len/1000)*fs);
shift_R = fr_N/4;

% Generate a sine-based input excitation model
pf = 120;

gp = sin(2*pi*(pf/fs).*[1:length(x1)])';
gp(gp<0) = 0;

gp_period = floor(fs/pf);
gp = sin(2*pi*(pf/fs).*[1:gp_period])';
gp(gp<0) = 0;


gp_cum = [];
for i = 1:ceil(length(x1)/gp_period)
    gp_cum = [gp_cum;gp];
    gp_cum = [gp_cum; zeros(round(10*rand),1)];
end

% We take a derivative of the gottal flow waveform to get to the glottal
% flow derivative. This is the input to the Source/Filter model:

e = diff(gp_cum);   
e = e+0.01*randn(length(e),1);

sum_w = zeros(8*fs,1);

for i = 1:shift_R:7*fs
    n=[i:i+fr_N-1];
    
    w = window(@triang,fr_N);
    xwin1 = x1(n).*w;
    
    [A1] = lpc(xwin1,10);

    E1 = filter(A1,1,xwin1);
    
    E2 = e([i:i+fr_N-1]).*w;
    
    g = sumsqr(E1)/sumsqr(E2);
    %xwin1_recon = filter(1,A1,.1*E2);
    xwin1_recon = filter(1,A1,sqrt(g)*E2);
    %xwin1_recon = filter(1,A2,E1);

    
    sum_w(n) = sum_w(n) + xwin1_recon;
end

plot(sum_w)

soundsc(sum_w)