clear
clc
close all


[x1 fs] = audioread('sustained_iy.wav');
x1 = x1(8.16e4:25.24e4);

[A1] = lpc(x1,16);
E1 = filter(A1,1,x1);
gp = cumsum(cumsum(E1))./([1:length(E1)])';
    plot([350:1000]/fs, gp(350:1000)+.06);
    title('Glottal Pulses');
    xlabel('Time (s)');
    
% fr = 10;
% gp_zm = [];
% for i = 1:fr:(length(E1)-fr)
%     n=[i:i+fr-1];
%     
%     gp_zm = [gp_zm;gp(n) - mean(gp(n))];
%     
% end
% 
% % plot(cumsum(E1))
% idx_min = [46 98 149 199 248];
% gp = [];
% for i = 1:length(idx_min)-1
% %     subplot(211)
% %     plot(cumsum(E1(idx_min(i):idx_min(i+1))))
% %     subplot(212)
% %     plot(cumsum(cumsum(E1(idx_min(i):idx_min(i+1)))))
%     gp = [gp;cumsum(cumsum(E1(idx_min(i):idx_min(i+1))))]
% 
% end
% plot(gp)

%   

% 
% 
% keyboard
% 
% 
% fs = fs1;
% 
% fr_len = 20;        % 20 ms frame
% fr_N = ((20/1000)*fs);
% shift_R = fr_N/4;
% 
% 
% 
% sum_w = zeros(8*fs,1);
% 
% for i = 1:shift_R:7*fs
%     n=[i:i+fr_N-1];
%     
%     w = window(@triang,fr_N);
%     xwin1 = x1(n).*w;
%     xwin2 = x2(n).*w;
%     [A1] = lpc(xwin1,10);
%     E1 = filter(A1,1,xwin1);
%   
%     [A2 E2] = lpc(xwin2,10);
%     E2 = filter(A2,1,xwin2);
%     
%     %xwin1_recon = filter(1,A1,.1*E2);
%     xwin1_recon = filter(1,A1,.3*E1+.7*E2);
%     
% %     subplot(211)
% %     plot(xwin1)
% %     subplot(212)
% %     plot(xwin2)
% %     keyboard
%     
%     sum_w(n) = sum_w(n) + xwin1_recon;
% end
% 
% plot(sum_w)
% 
% soundsc(sum_w)