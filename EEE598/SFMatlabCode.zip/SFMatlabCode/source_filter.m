clear
clc


%[x1 fs1] = audioread('SteveJob.wav');


[x1 fs1] = audioread('sustained_iy.wav');
x1 = resample(x1,160,441);
fs1 = 16000;
fs = fs1;

%x1 = x1(1.8e4:15.9999e4);




fr_len = 20;        % 20 ms frame
fr_N = ((fr_len/1000)*fs);
shift_R = fr_N/4;


sum_w = zeros(8*fs,1);

for i = 1:shift_R:6*fs
    n=[i:i+fr_N-1];
    
    w = window(@triang,fr_N);
    xwin1 = x1(n).*w;
    
    [A1] = lpc(xwin1,10);
    E1 = filter(A1,1,xwin1);
    
%     xwin1_recon = filter(1,A1,E1);
    
    xwin1_recon = E1;
    
    
    sum_w(n) = sum_w(n) + xwin1_recon;
end


% Original signal (glottal + filter)
fr_len = 20;        % 20 ms frame
fr_N = ((fr_len/1000)*fs);
shift_R = fr_N/2;
w = window(@triang,fr_N);
[S,F,T,P] = spectrogram(x1(1:6*fs),w,fr_N - shift_R,fr_N,fs);
figure
subplot(211)
imagesc(T,F,20*log10(abs(S)));
axis xy
xlabel('Time (s)')
ylabel('Frequency (Hz)');
subplot(212)
plot(20*log10(abs(S(:,200))))


% Excitation signal (glottal only)
[S,F,T,P] = spectrogram(sum_w,w,fr_N - shift_R,fr_N,fs);
figure
subplot(211)
imagesc(T,F,20*log10(abs(S)));
axis xy
xlabel('Time (s)')
ylabel('Frequency (Hz)');
xlim([0 6]) 
subplot(212)
plot(20*log10(abs(S(:,200))))


% 
% 
% plot(sum_w)
% 
% soundsc(sum_w)