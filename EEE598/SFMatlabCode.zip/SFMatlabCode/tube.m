clear
clc
close all


fs = 16000;

L = 9;

c = 35000;
n = [1:6];
fn = (2*n-1)*c/(4*L);

wn = 2*pi*(fn/(fs));

H = 0.1*rand(257,1);
W = linspace(0,pi,257);

for i = 1:length(wn)
    if wn(i) < pi
        [mm mm_idx] = min(abs(W - wn(i)));
        %H(mm_idx) = 10/i^2;
        H(mm_idx) = 10/i^2;
    end
end

stem(W,H)

Htime=ifft([H;H(end:-1:2)]);
Htime = Htime - mean(Htime);


A = lpc(Htime,30);


[e fs] = audioread('sa1.wav');



freqz(1,A,256)
snd = filter(1,A,e);


fr_len = 20;        % 20 ms frame
fr_N = ((fr_len/1000)*fs);
shift_R = fr_N/5;
w = window(@hamming,fr_N);


[S,F,T,P] = spectrogram(snd,w,fr_N - shift_R,fr_N,fs);
figure
imagesc(T,F,20*log10(abs(S)));
axis xy
xlabel('Time (s)')
ylabel('Frequency (Hz)');


soundsc(snd,fs);
