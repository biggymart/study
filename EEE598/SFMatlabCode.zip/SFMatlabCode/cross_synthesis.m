clear
clc


[x1 fs1] = audioread('SteveJob.wav');
[x2 fs2] = audioread('motorcycle.wav');

x2 = [x2;x2;x2;x2];

fs = fs1;

fr_len = 20;        % 20 ms frame
fr_N = ((fr_len/1000)*fs);
shift_R = fr_N/4;



sum_w = zeros(8*fs,1);

for i = 1:shift_R:7*fs
    n=[i:i+fr_N-1];
    
    w = window(@triang,fr_N);
    xwin1 = x1(n).*w;
    xwin2 = x2(n).*w;
    [A1] = lpc(xwin1,10);
    E1 = filter(A1,1,xwin1);
    
    [A2 E2] = lpc(xwin2,10);
    E2 = filter(A2,1,xwin2);
    
    g = sumsqr(E1)/sumsqr(E2);
    

    
    xwin1_recon = filter(1,A1,sqrt(g)*E2);
    
    xwin1_recon = filter(1,A1,0.001*E2);
   
   
%     subplot(211)
%     plot(xwin1)
%     subplot(212)
%     plot(xwin2)
%     keyboard
    
    sum_w(n) = sum_w(n) + xwin1_recon;
end



soundsc(sum_w)