close all ; clear all ; clc

A= [4 9 7 8 8; 
    2 1 0 3 5; 
    6 3 3 2 1];
% [~,x] = max(A(:,1));
% B = A(x,:);

M = max(A)