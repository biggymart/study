function av = gmmav(audio_file, C_num, rand_seed)
% Input
%   audio_file : (str) directory to speech file that you want to process
%   C_num : (int) number of cepstral coefficients; The article has is as 19.
%   rand_seed: (int) For reproducibility.

% read audio
[y,fs] = audioread(audio_file);

% resample the audio file to 16kHz
y = resample(y,16E3,fs);
fs = 16E3;

% find the mfcc of the audio file

Tw = 25;           % analysis frame duration (ms)
Ts = 10;           % analysis frame shift (ms)
alpha = 0.97;      % preemphasis coefficient
R = [ 300 3700 ];  % frequency range to consider
M = 20;            % number of filterbank channels 
C = C_num;            % number of cepstral coefficients
L = 12;            % cepstral sine lifter parameter

% hamming window (see Eq. (5.2) on p.73 of [1])
hamming = @(N)(0.54-0.46*cos(2*pi*[0:N-1].'/(N-1)));

% Feature extraction (feature vectors as columns)
[ MFCCs, FBEs, frames, eframes ] = ...
              mfcc( y, fs, Tw, Ts, alpha, hamming, R, M, C, L );

for i = 1:size(MFCCs,2)
    if and(i > 1,i<size(MFCCs,2))
        MFCCd(:,i) = (MFCCs(:,i+1) - MFCCs(:,i-1))/2;
    else
        MFCCd(:,i) = MFCCs(:,i);
    end      
end

for i = 1:size(MFCCs,2)
    if and(i > 1,i<size(MFCCs,2))
         MFCCdd(:,i) = (MFCCd(:,i+1) - MFCCd(:,i-1))/2;   
    else
        MFCCdd(:,i) = MFCCd(:,i);
    end
end

MFCCfeats = [MFCCs;MFCCd;MFCCdd];
% replace all NaN with 0
MFCCfeats(isnan(MFCCfeats))=0;
% 
% clear MFCCfeats MFCCs MFCCd MFCCdd;

% ** Construction **
% Error: X must have more rows than columns. --> transpose data
rng(rand_seed); % For reproducibility
GMModel = fitgmdist(MFCCfeats', 32, ... % The article states it to be 32 mixtures
                    'CovarianceType','diagonal', ...
                    'RegularizationValue',0.1);
Mu = GMModel.mu;

% compute the largest/smallest element in each column (feature)
Mu_max = max(Mu);
Mu_min = min(Mu);

edges = Mu_max - Mu_min;

av = prod(edges, 'all');
end