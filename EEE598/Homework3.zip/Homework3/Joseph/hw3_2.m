% Homework 3 Problem 2

% Pipeline description
% 1. Extract MFCC features.
% 2. Fit GMM model and get the model's means.
% 3. Compute GMM_AV by
%       (1) compute max and min 
%       (2) derive edges
%       (3) multiply all the edges.


% remove this section
close all ; clear all ; clc
% remove this section

% read in the audio file
audio_files = ["./audio/Regular.wav","./audio/Enunciated.wav","./audio/Depressed.wav"];

% number of cepstral coefficients
C_num = 19;

% an empty bucket for MFCC features
data = [];

for audio_file = audio_files
    
    % read audio
    [y,fs] = audioread(audio_file);
    
    % resample the audio file to 16kHz
    y = resample(y,16E3,fs);
    fs = 16E3;
    
    % find the mfcc of the audio file
    
    Tw = 25;           % analysis frame duration (ms)
    Ts = 10;           % analysis frame shift (ms)
    alpha = 0.97;      % preemphasis coefficient
    R = [ 300 3700 ];  % frequency range to consider
    M = 20;            % number of filterbank channels 
    C = C_num;            % number of cepstral coefficients
    L = 12;            % cepstral sine lifter parameter
    
    % hamming window (see Eq. (5.2) on p.73 of [1])
    hamming = @(N)(0.54-0.46*cos(2*pi*[0:N-1].'/(N-1)));
    
    % Feature extraction (feature vectors as columns)
    [ MFCCs, FBEs, frames, eframes ] = ...
                  mfcc( y, fs, Tw, Ts, alpha, hamming, R, M, C, L );
    
    for i = 1:size(MFCCs,2)
        if and(i > 1,i<size(MFCCs,2))
            MFCCd(:,i) = (MFCCs(:,i+1) - MFCCs(:,i-1))/2;
        else
            MFCCd(:,i) = MFCCs(:,i);
        end      
    end
    
    for i = 1:size(MFCCs,2)
        if and(i > 1,i<size(MFCCs,2))
             MFCCdd(:,i) = (MFCCd(:,i+1) - MFCCd(:,i-1))/2;   
        else
            MFCCdd(:,i) = MFCCd(:,i);
        end
    end
    
    MFCCfeats = [MFCCs;MFCCd;MFCCdd];
    % replace all NaN with 0
    MFCCfeats(isnan(MFCCfeats))=0;
    
    % ** For now, just cutting off the size into the shortest data size.
    % In this case, it just happens to be 265.
    % Improvement: get the maximum length of data and padding with 0s. **
    data = vertcat(data, MFCCfeats(:,1:265));
    clear MFCCfeats MFCCs MFCCd MFCCdd;
end

% ** Construction **
% Error: X must have more rows than columns. --> transpose data
rng(5); % For reproducibility
GMModel = fitgmdist(data', 32, ...
                    'CovarianceType','diagonal', ...
                    'RegularizationValue',0.1);
Mu = GMModel.mu;

% compute the largest/smallest element in each column (feature)
Mu_max = max(Mu);
Mu_min = min(Mu);

edges = Mu_max - Mu_min;

n_cep_coe=C_num*3; % 57
GMM_AV_1 = prod(edges(1:n_cep_coe),'all'); % regular
GMM_AV_2 = prod(edges(n_cep_coe+1 : n_cep_coe*2),'all'); % enunciated
GMM_AV_3 = prod(edges(n_cep_coe*2+1 : n_cep_coe*3),'all'); % depressed

disp(GMM_AV_1)
disp(GMM_AV_2)
disp(GMM_AV_3)