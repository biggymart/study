close all ; clear all ; clc


audio_files = dir([pwd '/audio/*.wav']);

for i = 1: length(audio_files)

    % read audio
    [y,fs] = audioread(audio_file.folder(i));
end