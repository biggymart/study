% https://www.phon.ucl.ac.uk/courses/spsci/matlab/lect10.html

% read and resample
[x, fs] = audioread('sustained_iy.wav');
x = resample(x,160,441);
fs = 16000;
%
% plot waveform
t=(0:length(x)-1)/fs;        % times of sampling instants
subplot(2,1,1);
plot(t,x);
legend('Waveform');
xlabel('Time (s)');
ylabel('Amplitude');
%
% get Linear prediction filter
ncoeff=2+fs/1000;           % rule of thumb for formant estimation
a=lpc(x,ncoeff);
%
% plot frequency response
[h,f]=freqz(1,a,512,fs);
subplot(2,1,2);
plot(f,20*log10(abs(h)+eps));
legend('LP Filter');
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');

% find frequencies by root-solving
r=roots(a);                  % find roots of polynomial a
r=r(imag(r)>0.01);           % only look for roots >0Hz up to fs/2
ffreq=sort(atan2(imag(r),real(r))*fs/(2*pi));
                             % convert to Hz and sort
for i=1:length(ffreq)
    fprintf('Formant %d Frequency %.1f\n',i,ffreq(i));
end
%%
% https://sail.usc.edu/~lgoldste/Ling582old/Week%2010/Assignment10.pdf
F = []; BW = [];
for i = 1:size(A,2)
   [Fi  BWi] = formants(A(:,i),sr);
   if G(i) <minG;
% don't plot formants of silent frames
       Fi = [nan;nan;nan;nan;nan];
       BWi = [nan;nan;nan;nan;nan];
   end;
   F = [F Fi(1:5)];
   BW = [BW BWi(1:5)];
end

%%
function [A, G] = get_lpc (signal, srate, M, window, slide)
%
% get_lpc
% Louis Goldstein
% March 2005
% 
% Output arguments:
% A			filter coefficients (M+1 rows x  nframes columns)
% G			Gain coefficients (vector length = nframes)
%
%
% input arguemnts:
% signal	signal to be analyzed
% srate		sampling rate in Hz
% M			LPC order  (def. = srate/1000 +4)
% window	size of analysis window in ms (def. = 10)
% slide		no. of ms. to slide analysis window for each frame (def. = 5)


if nargin < 3, M = floor(srate/1000) + 4; end
if nargin < 4, window = 20; end
if nargin < 5, slide = 10; end

samp_tot = length(signal);
samp_win = fix((window/1000)*srate);
samp_slide = fix((slide/1000)*srate);
nframes = floor(samp_tot/samp_slide) - ceil((samp_win-samp_slide)/samp_slide);

A = [];
G = [];

for i = 1:nframes
	begin = 1 + (i-1)*samp_slide;
	[Ai,Gi] = LPC (hamming(samp_win).*signal(begin:begin+samp_win-1),M);
	A = [A Ai'];
	G = [G Gi];
end

% %% https://personal.utdallas.edu/~assmann/hcs6389/lab3.pdf
% % slide p.17 - 20
% 
% % LPC root-solving using Matlab
% % compute linear prediction coefficients
% x= x.*hamming(500);
% p=12;
% a=lpc(x,p);
% 
% % LPC spectrum;
% nfft=512;
% logmag=-20*log10(abs(fft(a,nfft)));
% 
% % estimate formant frequencies, fk and
% % formant bandwidths, bk, from the roots
% % of the predictor polynomial
% r = roots(a);
% fk = fs / (2*pi)*atan2(imag(r), real(r));
% bk = fs / (2*pi)*log(1./abs(r));
% 
% % eliminate roots with frequencies < 100 Hz
% % eliminate roots with bandwidths > 500 Hz
% indices = find(fk<100);
% fk(indices)=[];
% bk(indices)=[];
% indices=find(bk>500);
% fk(indices)=[];
% bk(indices)=[];
% 
% % list the frequencies and bandwidths
% disp(round([fk bk]));