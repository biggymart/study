% Pipeline description
% 1. Read all the 50 words.
% 2. Find the maximum length.
% 3. Zero-pad according to the maximum length.
% 4. For time-frame 25ms and 10ms overlap, extract MFCC (39 features)
% 5. Build Euclidean classifier.

close all ; clear all ; clc

% 1. Read all the 50 words.
audio_files = ["./audio/Depressed.wav","./audio/Enunciated.wav","./audio/Regular.wav"];
% array containing audio file directories

% 2. Find the maximum length.
max_len = find_max_len(audio_files);
max_len = max_len - mod(max_len, 15); % subtract the remainder for shift_R


data = []; % so called "Answer sheet"
for audio_file = audio_files
    % read audio
    [y,fs] = audioread(audio_file);
    
    % resample the audio file to 16kHz
    y = resample(y,16E3,fs);
    fs = 16E3;
    
    % 3. Zero-pad according to the maximum length.
    padded = [audio_file; zeros(max_len-length(audio_file),1)];

    % 4. For time-frame 25ms and 10ms overlap, extract MFCC (39 features)
    fr_len = 25; % 25 ms frame
    fr_N = ((fr_len/1000)*fs);
    shift_R = 15; % 25 frame - 15 shift = 10 ms overlap
    
    for i = 1:shift_R:max_len % ** I'm not sure **
        % find the mfcc of the audio file
    
        Tw = 25;           % analysis frame duration (ms)
        Ts = 10;           % analysis frame shift (ms)
        alpha = 0.97;      % preemphasis coefficient
        R = [ 300 3700 ];  % frequency range to consider
        M = 20;            % number of filterbank channels 
        C = 12;            % number of cepstral coefficients
        L = 12;            % cepstral sine lifter parameter
        
        % hamming window (see Eq. (5.2) on p.73 of [1])
        hamming = @(N)(0.54-0.46*cos(2*pi*[0:N-1].'/(N-1)));
        
        % Feature extraction (feature vectors as columns)
        [ MFCCs, FBEs, frames, eframes ] = ...
            mfcc( padded(i:i+fr_N-1), fs, Tw, Ts, alpha, hamming, R, M, C, L );
            
            for i = 1:size(MFCCs,2)
                if and(i > 1,i<size(MFCCs,2))
                    MFCCd(:,i) = (MFCCs(:,i+1) - MFCCs(:,i-1))/2;
                else
                    MFCCd(:,i) = MFCCs(:,i);
                end      
            end
            
            for i = 1:size(MFCCs,2)
                if and(i > 1,i<size(MFCCs,2))
                     MFCCdd(:,i) = (MFCCd(:,i+1) - MFCCd(:,i-1))/2;   
                else
                    MFCCdd(:,i) = MFCCd(:,i);
                end
            end
            
            MFCCfeats = [MFCCs;MFCCd;MFCCdd];
            % replace all NaN with 0
            MFCCfeats(isnan(MFCCfeats))=0;
            
            % update the data with 39 MFCC features
            data = vertcat(data, MFCCfeats);
    end

end


% FUNCTIONS
function max_len = find_max_len(audio_files)
% Input
% audio_files: array containing audio file directories

max_len = 0;
for audio_file = audio_files
    
    % read audio
    [y,fs] = audioread(audio_file);
    
    % resample the audio file to 16kHz
    y = resample(y,16E3,fs);

    if max_len < length(y)
        max_len = length(y);
    end
end
end